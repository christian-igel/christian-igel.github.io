# Smooth Monotonic Networks: Supplementary material

## Appendix
The file `Smooth_appendix.pdf` contains the appendix of the paper, in particular additional experimental results and details about the experiments on UCI data.

##  Code
`SMM.zip` contains the source code for reproducing the experiments described in the paper and to perform new experiments, which is highly encouraged. The code will be distributed under the permissive **The MIT License**, which will be added later because the copyright holder name would break anonymity. It would be nice if you cite the paper if you use the code. 

The code will be cleaned up and moved to a proper public github repository incorporating feedback from the review process.

### Files
The files are:
 - `MonotonicNN.py`: Implementation of monotonic neural networks
 - `MonotonicNNPaperUtils.py`: Utility functions for the experiments in the paper (e.g., the gradient-based training procedures)
 - `MonotonicNNFullyMonotoneExperiments.ipynb`: Experiments on the fully monotone benchmark functions
 - `UCI validation.ipynb`: Experiments on UCI data
 - `MonotonicNNPaperEvaluate.ipynb`: For completeness, the notebook producing the figures and tables
 
### Dependencies
Among others, we compare against XGBoost, which can be installed via `pip install xgboost`, and the Hierarchical Lattice Layer, which can be installed via `pip install pmlayer`.
 
### Models
The file `MonotonicNN.py` implements several models. `MonotonicNN` and `MonotonicNNAlt` implement  the standard min-max (MM) architecture. The former is a simple implementation, the latter supports counting silent neurons. ``SmoothMonotonicNN`` and ``SmoothMonotonicNN`` implement the new SMM architecture. The first version is a simple implementation, the second supports partially monotone functions.  `SMM_MLP` implements the architecture with auxiliary network used for the  UCI experiments, see the appendix for details.
